

library(foreign)
library(balancer)
library(dplyr)
library(ggplot2)
library(sandwich)
library(splines)

rm(list=ls())

setwd("/Users/ljk20/Dropbox/Bal-Weights/data/class-size")
data <- read.dta("class-size.dta")

table(data$treat)

## Add Spline Bases
lnch.sp <- ns(data$lnch_pct, df=3, intercept=FALSE)
nos <- seq(1:ncol(lnch.sp))
colnames(lnch.sp) <- paste("lnch_pct", nos, sep="")

tot.sp <- ns(data$totsc4, df=3, intercept=FALSE)
nos <- seq(1:ncol(tot.sp))
colnames(tot.sp) <- paste("totsc4", nos, sep="")

spec.sp <- ns(data$spec_ed, df=3, intercept=FALSE)
nos <- seq(1:ncol(spec.sp))
colnames(spec.sp) <- paste("spec_ed", nos, sep="")


data <- cbind(data, lnch.sp, tot.sp, spec.sp)
covs <- c("percap","pctel","spend", "occ_spend",
colnames(lnch.sp), colnames(tot.sp), colnames(spec.sp), "-1")

X <- scale(model.matrix(reformulate(covs), data))
trt <- data$treat
n <- nrow(data)

data.c <- data %>% filter(treat==0)
lambda.reg <- lm(std_test ~ percap + pctel + spend + occ_spend + lnch_pct1 + lnch_pct2 + 
                 lnch_pct3 + totsc41 + totsc42 + totsc43 + spec_ed1 + spec_ed2 + 
                 spec_ed3, data=data.c)
l <- var(lambda.reg$resid)
l

out.clsz <- multilevel_qp(X, trt, rep(1,n), lambda = l, verbose= TRUE, exact_global = FALSE, scale_sample_size = FALSE)

# Process the Weights
data$wts <- pmax(out.clsz$weights, 0)
data$wts[data$treat == 1] <- 1
summary(data$wts)


## PS Wts
psmod <- glm(reformulate(covs, response = "treat"),  family = binomial(), data = data)
ip <- ifelse(data$treat == 0, exp(psmod$linear.predictors), 1)                
data$ip.wts <- ip

summary(data$ip.wts)

# ESS
nrow(data)
table(data$treat)

data.trt <- data %>% filter(treat==1)
n.trt <- (sum(data.trt$wts)^2) / (sum(data.trt$wts^2))
data.ctl <- data %>% filter(treat==0)
n.ctrl <- (sum(data.ctl$wts)^2) / (sum(data.ctl$wts^2))

n.trt
n.ctrl
n.trt + n.ctrl

## IP Weights ESS
n.trt.ip <- (sum(data.trt$ip.wts)^2) / (sum(data.trt$ip.wts^2))
n.ctrl <- (sum(data.ctl$ip.wts)^2) / (sum(data.ctl$ip.wts^2))

n.trt.ip
n.ctrl
n.trt.ip + n.ctrl

## Balance
basis <- reformulate(covs)                     
X <- model.matrix(as.formula(basis), data)

bal.data <- as.data.frame(X)
bal.names <- names(bal.data)
n_covs <- length(bal.names)
bal.data$treat <- data$treat
bal.data$wts <- data$wts
bal.data$ip.wts <- data$ip.wts

data.var <- bal.data %>% group_by(treat) %>% 
   summarize(across(all_of(bal.names), ~var(.x))) %>% as.data.frame()
   
c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.var <- sqrt((t.var + c.var)/2)

## Balance
um.wt <- bal.data %>% group_by(treat) %>% 
   summarize(across(all_of(bal.names), ~mean(.x))) %>% as.data.frame()

bal.st <- bal.data %>% group_by(treat) %>% 
   summarize(across(all_of(bal.names), ~ weighted.mean(.x, wts))) %>% as.data.frame()

bal.ip <- bal.data %>% group_by(treat) %>% 
   summarize(across(all_of(bal.names), ~ weighted.mean(.x, ip.wts))) %>% as.data.frame()  
                  
um.wt.tab <- matrix(NA, length(bal.names), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.var

bal.st.tab <- matrix(NA, length(bal.names), 3)
bal.st.tab[,1] <- unlist(bal.st[1,-1]) 
bal.st.tab[,2] <- unlist(bal.st[2,-1])                        
bal.st.tab[,3] <- (unlist(bal.st[2,-1]) - unlist(bal.st[1,-1]))/pooled.var

bal.ip.tab <- matrix(NA, length(bal.names), 3)
bal.ip.tab[,1] <- unlist(bal.ip[1,-1]) 
bal.ip.tab[,2] <- unlist(bal.ip[2,-1])                        
bal.ip.tab[,3] <- (unlist(bal.ip[2,-1]) - unlist(bal.ip[1,-1]))/pooled.var

um.wt.bias <- um.wt.tab[,3]
bal.bias <- bal.st.tab[,3] 
ip.wt.bias <- bal.ip.tab[,3]

## Bias Reduction
pbr.bal.wt <- (1 - (mean(abs(bal.bias))/mean(abs(um.wt.bias))))*100
pbr.ip.wt <- (1 - (mean(abs(ip.wt.bias))/mean(abs(um.wt.bias))))*100

pbr.bal.wt
pbr.ip.wt

## Balance Subset
rownames(um.wt.tab) <- bal.names
          
 ### Plots and Tables
n_covs <- nrow(um.wt.tab)
var_names <- c("Per Capita Income","Pct English Learner", 
                "Above Average Spending Per Pupil", "Above Average Occp Spending Per Pupil",
                "Free Lunch Spline 1", "Free Lunch Spline 2", "Free Lunch Spline 3", "Past Test Scores Spline 1",
               "Past Test Scores Spline 2", "Past Test Scores Spline 3",
               "% Spec Ed Spline 1", "% Spec Ed Spline 2", "% Spec Ed Spline 3")

#### Balance Plot
data.plot <- c(um.wt.tab[,3], bal.st.tab[,3])
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "std.dif"
data.plot$contrast <- c(rep(1, n_covs), rep(2, n_covs))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2), labels = c("Unweighted", "Weighted"))
data.plot$covariate <- as.factor(var_names)

ggplot(data=data.plot, aes(x=std.dif, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,12, 20)) + 
          xlab("Standardized Difference") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          geom_vline(xintercept= 0) +
          geom_vline(xintercept= 0.2, linetype = "dashed") +
          geom_vline(xintercept= -0.2, linetype = "dashed") +
          theme_bw()
 

data.plot <- c(bal.ip.tab[,3], bal.st.tab[,3])
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "std.dif"
data.plot$contrast <- c(rep(1, n_covs), rep(2, n_covs))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2), labels = c("Model-Based Weights", "Balancing Weights"))
data.plot$covariate <- as.factor(var_names)

ggplot(data=data.plot, aes(x=std.dif, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,12, 20)) + 
          xlab("Standardized Difference") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          geom_vline(xintercept= 0) +
          theme_bw()
          
           
          geom_vline(xintercept= 0.1, linetype = "dashed") +
          geom_vline(xintercept= -0.1, linetype = "dashed") +
        

## Outcome Estimates
          
msm.out <- function(obj){
	SE <- sqrt(diag(vcovHC(obj, type="HC0")))[2] # robust standard errors
    beta <- coef(obj)[2]
    lcl <- (beta - abs(qnorm(.025))*SE)
    ucl <- (beta + abs(qnorm(.025))*SE)
    return(c(beta, lcl, ucl, SE))
   }

# Outcomes
tst.bal.wt <- lm(std_test ~ treat, data=data, weights = wts)
tst.bal.wt.att <- msm.out(tst.bal.wt)
tst.bal.wt.att

sr.att <- sum((data$std_test -(1 - data$treat)*data$wts)*data$std_test)/sum(data$treat)
sr.att

tst.ip.wt <- lm(std_test ~ treat, data=data, weights = ip.wts)
tst.ip.wt.att <- msm.out(tst.ip.wt)
tst.ip.wt.att

## AIPW
covs <- covs <- c("percap","pctel","spend", "occ_spend",
colnames(lnch.sp), colnames(tot.sp), colnames(spec.sp))

#Outcome Model for Control
eta0.glm <- lm(reformulate(covs, response="std_test"), subset=treat==0, data=data)
x <- model.matrix(reformulate(covs), data)
mu0 <- predict(eta0.glm, newdata=data.frame(x), type="response")

a.covs <- c("treat","percap","pctel","spend", "occ_spend",
colnames(lnch.sp), colnames(tot.sp), colnames(spec.sp))

dr.att <- sum((data$treat -(1 - data$treat)*data$wts)*(data$std_test - mu0))/sum(data$treat)
dr.att
 
math.dr <- lm(reformulate(a.covs, response="std_test"), data=data, weights = wts)
math.dr.att <- msm.out(math.dr)
math.dr.att

## Sens Analysis
source("sens-funcs.R")

Y <- data$std_test
extrema_os(trt, X, Y, rep(1,n), multilevel_qp, 0, lambda = l)

## Bounds Include Zero When Lambda = 1.14
extrema_os(trt, X, Y, rep(1,n), multilevel_qp, 0.13, lambda = l)




